const express = require('express');
const cors = require('cors')
const bodyParser = require('body-parser');
const connection = require('./db_config.js');

const app = express();
const port = 3000;

app.use(express.json());
app.use(cors())
app.listen(port, () => console.log(`Rodando na porta ${port}`));

// Rotas usuarios
app.post('/usuarios', (request, response) => {
    const { nome, email, senha } = request.body;

    let query = "INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?);"
    connection.query(query, [nome, email, senha], (err, results) => {
        if (err) {
            return response.status(400).json({
                success: false,
                message: "Erro ao cadastrar usuario!",
                data: err
            });
        } else {
            return response.status(201).json({
                success: true,
                message: "Usuario cadastrado com sucesso!",
                data: results
            });
        }
    });
});


app.get('/usuarios', (request, response) => {
    let query = "SELECT * FROM usuarios";
    connection.query(query, (err, results) => {
        if (results) {
            response.status(200).json({
                success: true,
                message: "Lista de usuarios obtida com sucesso!",
                data: results
            });
        } else {
            response.status(400).json({
                success: false,
                message: "Erro ao buscar usuarios!",
                data: err
            });
        }
    });
});

app.put('/usuarios/:id', (req, res) => {
    const { nome, email, senha } = req.body;
    const id = parseInt(req.params.id);

    console.log("Body recebido:", req.body);

    const sql = `
            UPDATE usuarios
            SET nome = ?, email = ?, senha = ?
            WHERE id = ?;
        `;

    const params = [nome, email, senha, id];

    connection.query(sql, params, (err, results) => {
        if (err) {
            return res.status(400).json({
                success: false,
                message: "Erro ao editar usuário!",
                data: err
            });
        }

        return res.status(200).json({
            success: true,
            message: "Usuário atualizado!",
            data: results
        });
    });
});

// Rotas perguntas

app.post('/perguntas', (request, response) => {
    const { usuario_id, area, duvida } = request.body;

    let query = "INSERT INTO perguntas (usuario_id, area, duvida) VALUES (?, ?, ?);";
    connection.query(query, [usuario_id, area, duvida], (err, results) => {
        if (err) {
            return response.status(400).json({
                success: false,
                message: "Erro ao cadastrar pergunta!",
                data: err
            });
        } else {
            return response.status(201).json({
                success: true,
                message: "Pergunta cadastrada com sucesso!",
                data: results
            });
        }
    });
});

app.get('/perguntas', (request, response) => {
    let query = `
        SELECT perguntas.*, usuarios.nome AS usuario_nome
        FROM perguntas
        JOIN usuarios ON perguntas.usuario_id = usuarios.id
    `;
    connection.query(query, (err, results) => {
        if (results) {
            response.status(200).json({
                success: true,
                message: "Lista de perguntas obtida com sucesso!",
                data: results
            });
        } else {
            response.status(400).json({
                success: false,
                message: "Erro ao buscar perguntas!",
                data: err
            });
        }
    });
});


// Rotas respostas

app.post("/respostas", (request, response) => {
    const { respondente_id, pergunta_id, resposta } = request.body;

    const query = "INSERT INTO respostas (respondente_id, pergunta_id, resposta) VALUES (?, ?, ?)";

    connection.query(query, [respondente_id, pergunta_id, resposta], (err, results) => {
        if (err) {
            return response.status(400).json({
                success: false,
                message: "Erro ao cadastrar resposta!",
                data: err
            });
        } else {
            return response.status(201).json({
                success: true,
                message: "Resposta cadastrada com sucesso!",
                data: results
            });
        }
    });
});

app.get('/respostas', (request, response) => {
    let query = `
        SELECT respostas.*, usuarios.nome AS respondente_nome
        FROM respostas
        JOIN usuarios ON respostas.respondente_id = usuarios.id
    `;
    connection.query(query, (err, results) => {
        if (results) {
            response.status(200).json({
                success: true,
                message: "Lista de respostas obtida com sucesso!",
                data: results
            });
        } else {
            response.status(400).json({
                success: false,
                message: "Erro ao buscar respostas!",
                data: err
            });
        }
    });
});

// metches

let matches = []

app.post('/matches', (req, res) => {
    const { perguntaId, respondenteId, perguntaUsuarioNome, respondenteNome } = req.body;

    if (!perguntaId || !respondenteId || !perguntaUsuarioNome || !respondenteNome) {
        return res.status(400).json({ success: false, message: 'Dados incompletos.' });
    }

    matches.push({
        perguntaId,
        respondenteId,
        perguntaUsuarioNome,
        respondenteNome
    });

    res.json({ success: true, message: 'Match criado com sucesso!' });
});

app.get('/matches', (req, res) => {
    res.json({ success: true, data: matches });
});