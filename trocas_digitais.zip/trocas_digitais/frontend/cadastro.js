document.addEventListener("DOMContentLoaded", () => {
    const formCadastro = document.getElementById("formulario");

    formCadastro.addEventListener("submit", async (e) => {
        e.preventDefault();

        const nome = document.getElementById("nome").value;
        const email = document.getElementById("email").value;
        const senha = document.getElementById("senha").value;

        try {
            const response = await fetch("http://localhost:3000/usuarios", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ nome, email, senha })
            });

            const data = await response.json();

            if (data.success) {
                alert("Cadastro realizado com sucesso!");
                window.location.href = "feed.html";
            } else {
                alert("Erro ao cadastrar: " + data.message);
            }
        } catch (error) {
            alert("Erro de conexão com o servidor: " + error.message);
        }
    });
});
