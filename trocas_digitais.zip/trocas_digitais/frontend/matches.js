document.addEventListener("DOMContentLoaded", async () => {
    const listaMatches = document.getElementById('lista-matches');

    try {
        const response = await fetch("http://localhost:3000/matches");
        const matchesData = await response.json();

        if (matchesData.success) {
            const matches = matchesData.data;

            if (matches.length === 0) {
                listaMatches.innerHTML = '<p>Você ainda não tem matches 😢</p>';
                return;
            }

            matches.forEach(match => {
                const div = document.createElement('div');
                div.classList.add('match-card');

                div.innerHTML = `
            <h3>🤝 Novo Match!</h3>
            <p><strong>Usuário da Pergunta:</strong> @${match.perguntaUsuarioNome}</p>
            <p><strong>Respondente:</strong> @${match.respondenteNome}</p>
          `;

                listaMatches.appendChild(div);
            });
        } else {
            listaMatches.innerHTML = '<p>Erro ao carregar matches.</p>';
        }
    } catch (error) {
        console.error('Erro:', error);
        listaMatches.innerHTML = '<p>Erro ao carregar matches.</p>';
    }
});  