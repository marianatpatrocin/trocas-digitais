document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById('form-ajuda');

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const nome = document.getElementById('nome').value;
        const area = document.getElementById('area').value;
        const duvida = document.getElementById('duvida').value;

        try {
            const usuarios = await fetch('http://localhost:3000/usuarios').then(r => r.json());
            const usuario = usuarios.data.find(u => u.nome === nome);

            if (!usuario) {
                alert('Usuário não encontrado!');
                return;
            }

            const response = await fetch('http://localhost:3000/perguntas', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ usuario_id: usuario.id, area, duvida })
            });

            const result = await response.json();
            if (result.success) {
                alert('Pergunta enviada!');
                window.location.href = 'feed.html';
            } else {
                alert('Erro ao enviar pergunta: ' + result.message);
            }
        } catch (err) {
            alert('Erro de conexão: ' + err.message);
        }
    });
});

