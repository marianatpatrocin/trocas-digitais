document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById('form-resposta');
    const urlParams = new URLSearchParams(window.location.search);
    const perguntaId = urlParams.get('pergunta_id');

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const nome = document.getElementById('nome-respondente').value;
        const respostaTexto = document.getElementById('resposta').value;

        try {
            const usuarios = await fetch('http://localhost:3000/usuarios').then(r => r.json());
            const usuario = usuarios.data.find(u => u.nome === nome);

            if (!usuario) {
                alert('Usuário não encontrado!');
                return;
            }

            const response = await fetch('http://localhost:3000/respostas', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    pergunta_id: Number(perguntaId),
                    respondente_id: usuario.id,
                    resposta: respostaTexto
                })
            });

            const result = await response.json();
            if (result.success) {
                alert('Resposta enviada!');
                window.location.href = 'feed.html';
            } else {
                alert('Erro ao enviar resposta: ');
            }
        } catch (err) {
            alert('Erro de conexão: ');
        }
    });
});