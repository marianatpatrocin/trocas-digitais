document.addEventListener("DOMContentLoaded", async () => {
    const feed = document.getElementById('feed');

    try {
        const perguntasResponse = await fetch("http://localhost:3000/perguntas");
        const perguntasData = await perguntasResponse.json();

        const respostasResponse = await fetch("http://localhost:3000/respostas");
        const respostasData = await respostasResponse.json();

        if (perguntasData.success && respostasData.success) {
            const todasPerguntas = perguntasData.data;
            const todasRespostas = respostasData.data;

            const url = window.location.href;
            let areaAtual = '';

            if (url.includes('programacao.html')) {
                areaAtual = 'PROGRAMAÇÃO';
            } else if (url.includes('design.html')) {
                areaAtual = 'DESIGN';
            } else if (url.includes('materiais.html')) {
                areaAtual = 'MATERIAIS DE ESTUDO';
            } else if (url.includes('projetos.html')) {
                areaAtual = 'PROJETOS';
            }

            todasPerguntas.forEach(pergunta => {
                if (areaAtual && pergunta.area !== areaAtual) return;

                const div = document.createElement('div');
                div.classList.add('duvida');

                div.innerHTML = `
            <h3>Usuário: @${pergunta.usuario_nome}</h3>
            <p><strong>Área:</strong> ${pergunta.area}</p>
            <p><strong>Dúvida:</strong> ${pergunta.duvida}</p>
            <a href="responder.html?pergunta_id=${pergunta.id}"><button>Responder</button></a>
            <button class="ver-respostas" data-id="${pergunta.id}" data-usuario-nome="${pergunta.usuario_nome}">Ver Respostas</button>
            <div class="respostas" id="respostas-${pergunta.id}" style="display: none;"></div>
          `;

                feed.appendChild(div);
            });

            document.querySelectorAll(".ver-respostas").forEach(botao => {
                botao.addEventListener("click", function () {
                    const perguntaId = this.getAttribute("data-id");
                    const perguntaUsuarioNome = this.getAttribute("data-usuario-nome");
                    const divRespostas = document.getElementById(`respostas-${perguntaId}`);

                    if (divRespostas.style.display === 'block') {
                        divRespostas.style.display = 'none';
                        this.innerText = 'Ver Respostas';
                        return;
                    }

                    const respostasRelacionadas = todasRespostas.filter(r => r.pergunta_id == perguntaId);

                    if (respostasRelacionadas.length > 0) {
                        divRespostas.innerHTML = respostasRelacionadas.map(r => `
                <div class="resposta">
                  <p><strong>Respondente:</strong> @${r.respondente_nome}</p>
                  <p>${r.resposta}</p>
                  <button class="botao-match" onclick="criarMatch(${r.pergunta_id}, ${r.respondente_id}, '${perguntaUsuarioNome}', '${r.respondente_nome}')">Dar Match 🤝</button>
                </div>
              `).join('');
                    } else {
                        divRespostas.innerHTML = "<p>Sem respostas ainda.</p>";
                    }

                    divRespostas.style.display = 'block';
                    this.innerText = 'Ocultar Respostas';
                });
            });
        }
    } catch (error) {
        console.error('Erro:', error);
    }
});


//match
function criarMatch(perguntaId, respondenteId, perguntaUsuarioNome, respondenteNome) {
    fetch('http://localhost:3000/matches', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            perguntaId,
            respondenteId,
            perguntaUsuarioNome,
            respondenteNome
        }),
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Match realizado com sucesso!');
            } else {
                alert('Erro ao realizar match.');
            }
        });
}
